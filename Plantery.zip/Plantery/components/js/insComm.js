reportApp = angular.module('angCommApp', []);

reportApp.controller('InsCommController',  function($scope, $http) {

})